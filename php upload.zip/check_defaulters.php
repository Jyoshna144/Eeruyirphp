<?php
// Include the database configuration file
include 'config.php';

// SQL query to select patient_id from defaulters_list
$sql_check_defaulters = "
    SELECT patient_id FROM defaulters_list
";

// Prepare and execute the query
$stmt_check_defaulters = $conn->prepare($sql_check_defaulters);
$stmt_check_defaulters->execute();

// Fetch all the results
$defaulters = $stmt_check_defaulters->fetchAll(PDO::FETCH_ASSOC);

// Return the results as a JSON response
if ($defaulters) {
    // Output the list of defaulters as JSON
    echo json_encode($defaulters);
} else {
    // If no defaulters are found, return an empty JSON array
    echo json_encode([]);
}

// Close the PDO connection (optional)
$conn = null;
?>