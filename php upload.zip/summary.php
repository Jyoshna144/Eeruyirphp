<?php
// Include your database configuration file
include 'config.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

try {
    // Query to retrieve patient names and their response counts
    $sql = "
        SELECT
            p.patient_id AS patient_id,
            SUM(CASE WHEN m.response = 'MORE RELAXED' THEN 1 ELSE 0 END) AS more_relaxed,
            SUM(CASE WHEN m.response = 'HAPPY' THEN 1 ELSE 0 END) AS happy,
            SUM(CASE WHEN m.response = 'LESS ANXIOUS' THEN 1 ELSE 0 END) AS less_anxious,
            SUM(CASE WHEN m.response = 'NO CHANGE' THEN 1 ELSE 0 END) AS no_change
        FROM patientsignup p
        LEFT JOIN mental_health_data m ON p.patient_id = m.patient_id
        GROUP BY p.patient_id
        ORDER BY p.patient_id
    ";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return results as JSON
    echo json_encode($results);

} catch (PDOException $e) {
    // Handle database-related errors
    echo json_encode(['error' => 'Database Error: ' . $e->getMessage()]);
}
?>