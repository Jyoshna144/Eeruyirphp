<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file
require 'config.php';

// Get the JSON data from the request body
$data = json_decode(file_get_contents("php://input"), true);
$patient_id = isset($data['patient_id']) ? $data['patient_id'] : null;

// Check if patient ID is provided
if (!$patient_id) {
    echo json_encode(['success' => false, 'message' => 'Patient ID is required.']);
    exit;
}

try {
    // Prepare the SQL statement to get all alerts for the patient, including alert_id
    $sql = "SELECT id AS alert_id, patient_id, alert_message, created_at, is_acknowledged 
            FROM patient_alerting 
            WHERE patient_id = :patient_id AND is_acknowledged = 0
            ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
    $stmt->execute();

    // Fetch all the alerts
    $alerts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($alerts) {
        echo json_encode(['success' => true, 'alerts' => $alerts]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No alerts found.']);
    }
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

// Close the connection
$conn = null;
?>