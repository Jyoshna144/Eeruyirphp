<?php
// Allow cross-origin requests and set content type
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database configuration
require "config.php";

try {
    // Get JSON data from request
    $data = json_decode(file_get_contents("php://input"), true);
    error_log("Received Data: " . print_r($data, true));

    // Validate required fields
    if (!isset($data['patientId']) || !isset($data['responses'])) {
        throw new Exception("Missing required fields.");
    }

    $patient_id = htmlspecialchars(strip_tags($data['patientId']));
    $responses = $data['responses'];

    // Prepare statements for checking, updating, and inserting responses
    $stmt_check = $conn->prepare("SELECT patientId FROM patient_responses WHERE patientId = :patientId AND questionId = :questionId");
    $stmt_update = $conn->prepare("UPDATE patient_responses SET answer = :answer WHERE patientId = :patientId AND questionId = :questionId");
    $stmt_insert = $conn->prepare("INSERT INTO patient_responses (patientId, categoryId, questionId, answer, created_at) VALUES (:patientId, :categoryId, :questionId, :answer, NOW())");

    // Iterate through each response to check, update, or insert
    foreach ($responses as $response) {
        $questionId = htmlspecialchars(strip_tags($response['questionId']));
        $categoryId = htmlspecialchars(strip_tags($response['categoryId']));
        $answer = htmlspecialchars(strip_tags($response['answer']));

        // Check if response exists
        $stmt_check->execute([':patientId' => $patient_id, ':questionId' => $questionId]);

        // Fetch results to avoid unbuffered query issues
        $existingResponses = $stmt_check->fetchAll(PDO::FETCH_ASSOC);

        if (count($existingResponses) > 0) {
            // Update existing response
            $stmt_update->execute([
                ':patientId' => $patient_id,
                ':questionId' => $questionId,
                ':answer' => $answer
            ]);
            error_log("Updated response - patientId: $patient_id, questionId: $questionId, answer: $answer");
        } else {
            // Insert new response
            $stmt_insert->execute([
                ':patientId' => $patient_id,
                ':categoryId' => $categoryId,
                ':questionId' => $questionId,
                ':answer' => $answer
            ]);
            error_log("Inserted new response - patientId: $patient_id, categoryId: $categoryId, questionId: $questionId, answer: $answer");
        }
    }

    // Return success message
    http_response_code(200);
    echo json_encode(["message" => "Answers saved successfully.", "patientId" => $patient_id]);
} catch (Exception $e) {
    // Handle errors
    http_response_code(500);
    echo json_encode(["message" => $e->getMessage()]);
} finally {
    // Close the connection
    $conn = null;
}
?>