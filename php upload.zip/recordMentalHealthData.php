<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include 'config.php'; // Include your database configuration

try {
    // Retrieve patientId, mentalHealth, and date from POST request
    $patientId = $_POST['patientId'];
    $response = $_POST['mentalHealth'];
    $date = $_POST['date'];

    // Check if patientId, mentalHealth, and date are provided
    if (empty($patientId) || empty($response) || empty($date)) {
        throw new Exception("Patient ID, mental health response, and date are required fields.");
    }

    // Prepare SQL statement to insert data
    $sql = "INSERT INTO mental_health_data (patient_id, response, date)
            VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Execute the statement with the provided data
    $stmt->execute([$patientId, $response, $date]);

    // Success message
    echo "Mental health data recorded successfully.";
} catch (PDOException $e) {
    // Handle database-related errors
    echo "Database Error: " . $e->getMessage();
} catch (Exception $e) {
    // Handle other errors
    echo "Error: " . $e->getMessage();
}
?>