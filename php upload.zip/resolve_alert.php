<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file
require 'config.php';

// Get the JSON data from the request body
$data = json_decode(file_get_contents("php://input"), true);
$alert_id = isset($data['alert_id']) ? $data['alert_id'] : null;
$patient_id = isset($data['patient_id']) ? $data['patient_id'] : null;

// Check if alert ID and patient ID are provided
if (!$alert_id || !$patient_id) {
    echo json_encode(['success' => false, 'message' => 'Alert ID and Patient ID are required.']);
    exit;
}

try {
    // Prepare the SQL statement to resolve the alert
    $sql = "UPDATE patient_alerting SET is_acknowledged = 1 WHERE id = :alert_id AND patient_id = :patient_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':alert_id', $alert_id, PDO::PARAM_INT);
    $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Alert resolved successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'No matching alert found.']);
    }
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

// Close the connection
$conn = null;
?>