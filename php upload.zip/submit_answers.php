<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration file
include 'config.php';

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Check if patient_id and answers are provided
if (!isset($data['patient_id']) || !isset($data['answers'])) {
    echo json_encode(['error' => 'patient_id and answers are required']);
    exit;
}

$patient_id = $data['patient_id'];
$answers = $data['answers'];

// Get the current date (in YYYY-MM-DD format)
$current_date = date('Y-m-d');

// Loop through each answer and insert it into the database
foreach ($answers as $answer) {
    $question_id = $answer['question_id'];
    $answer_text = $answer['answer'];

    // Insert the answer into the database
    $sql = "INSERT INTO patient_answers (patient_id, question_id, answer, answer_date) 
            VALUES (:patient_id, :question_id, :answer, :answer_date)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':patient_id', $patient_id);
    $stmt->bindParam(':question_id', $question_id);
    $stmt->bindParam(':answer', $answer_text);
    $stmt->bindParam(':answer_date', $current_date); // Bind the current date

    if (!$stmt->execute()) {
        echo json_encode(['error' => 'Failed to save answer for question ' . $question_id]);
        exit;
    }
}

$conn = null;

echo json_encode(['success' => 'Answers saved successfully']);
?>