<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database configuration
include 'config.php';

try {
    // Check if patient_id is provided
    if (isset($_GET['patient_id'])) {
        $patient_id = $_GET['patient_id'];

        // Prepare the SQL query
        $sql = "SELECT COUNT(*) AS notification_count 
                FROM patient_alerting 
                WHERE patient_id = :patient_id AND is_acknowledged = 0";

        // Execute the query
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $stmt->execute();

        // Fetch the result
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Return the count as JSON
        echo json_encode(array(
            "status" => "success",
            "notification_count" => $result['notification_count']
        ));
    } else {
        // Return error if patient_id is missing
        echo json_encode(array(
            "status" => "error",
            "message" => "Patient ID is required."
        ));
    }
} catch (PDOException $e) {
    // Handle potential errors
    echo json_encode(array(
        "status" => "error",
        "message" => $e->getMessage()
    ));
}
?>