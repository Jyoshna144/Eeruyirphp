<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include 'config.php'; // Include your database connection

// Directory for profile images
$targetDir = "uploads/profile/";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Upload or update profile photo
    $patient_id = isset($_POST['patient_id']) ? htmlspecialchars($_POST['patient_id']) : null;

    if ($patient_id && isset($_FILES["profileImage"]) && $_FILES["profileImage"]["error"] === UPLOAD_ERR_OK) {
        $fileType = strtolower(pathinfo($_FILES["profileImage"]["name"], PATHINFO_EXTENSION));
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($fileType, $allowedTypes)) {
            $targetFile = $targetDir . $patient_id . '.' . $fileType;

            // Move uploaded file to the target directory
            if (move_uploaded_file($_FILES["profileImage"]["tmp_name"], $targetFile)) {
                // Update database with the profile photo path
                // Assuming you have a base URL defined properly
                $baseUrl = "http://180.235.121.245/eeruyir/";
                $profileImageUrl = $baseUrl . $targetFile;



                $stmt = $conn->prepare("REPLACE INTO patient_profiles (patient_id, profile_photo) VALUES (:patient_id, :profile_photo)");
                $stmt->bindParam(':patient_id', $patient_id);
                $stmt->bindParam(':profile_photo', $profileImageUrl);

                if ($stmt->execute()) {
                    echo json_encode(['message' => 'Profile image uploaded and saved successfully.', 'path' => $profileImageUrl]);
                } else {
                    echo json_encode(['message' => 'Failed to save the profile in the database.']);
                }
            } else {
                echo json_encode(['message' => 'Failed to move the uploaded file.']);
            }
        } else {
            echo json_encode(['message' => 'Invalid file type. Only JPG, JPEG, PNG, and GIF are allowed.']);
        }
    } else {
        echo json_encode(['message' => 'Invalid or missing patient ID or file upload error.']);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Retrieve profile photo
    $patient_id = isset($_GET['patient_id']) ? htmlspecialchars($_GET['patient_id']) : null;

    if ($patient_id) {
        $stmt = $conn->prepare("SELECT profile_photo FROM patient_profiles WHERE patient_id = :patient_id");
        $stmt->bindParam(':patient_id', $patient_id);

        if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                echo json_encode(['profile_photo' => $result['profile_photo']]);
            } else {
                echo json_encode(['message' => 'No profile found for the provided patient ID.']);
            }
        } else {
            echo json_encode(['message' => 'Failed to retrieve the profile from the database.']);
        }
    } else {
        echo json_encode(['message' => 'Invalid or missing patient ID.']);
    }
} else {
    echo json_encode(['message' => 'Invalid request method. Use POST to upload or GET to retrieve.']);
}

?>