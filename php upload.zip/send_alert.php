<?php
// Set the response header to JSON
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file
require 'config.php';

// Get the JSON data from the request body
$data = json_decode(file_get_contents("php://input"), true);
$patient_id = isset($data['patient_id']) ? $data['patient_id'] : null;
$message = isset($data['message']) ? $data['message'] : null;

// Check if patient ID and message are provided
if (!$patient_id || !$message) {
    echo json_encode(['success' => false, 'message' => 'Patient ID and message are required.']);
    exit;
}

try {
    // Prepare SQL statement to insert the alert into the database
    $sql = "INSERT INTO patient_alerting(patient_id, alert_message, created_at) VALUES (:patient_id, :alert_message, NOW())";
    $stmt = $conn->prepare($sql);  // Use $conn instead of $pdo for the database connection

    // Bind parameters (explicitly bind as string for patient_id)
    $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
    $stmt->bindParam(':alert_message', $message);

    // Execute the statement
    if ($stmt->execute()) {
        // Simulate sending alert (e.g., email, notification, etc.)
        echo json_encode(['success' => true, 'message' => 'Alert sent successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error sending alert.']);
    }
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage()); // Log the error for debugging
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

// Close the database connection (optional)
$conn = null;
?>