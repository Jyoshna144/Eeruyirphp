<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration file
include 'config.php';

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Check if patient_id, month, and alert_id are provided
if (!isset($data['patient_id']) || !isset($data['month'])) {
    echo json_encode(['error' => 'patient_id and month are required']);
    exit;
}

$patient_id = $data['patient_id'];
$month = $data['month'];

try {
    // Check for alerts for the given patient_id and month
    $sql = "SELECT a.id, a.alert_message, a.tests_required, a.scan_required 
            FROM alerts a 
            WHERE a.month = :month";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':month', $month);
    $stmt->execute();

    // Fetch the alert
    $alert = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($alert) {
        // Check if this alert has been acknowledged by looking it up in the scans table
        $alertId = $alert['id']; // Get the id of the alert

        $scanCheckSql = "SELECT COUNT(*) FROM scans WHERE patient_id = :patient_id AND alert_id = :alert_id";
        $scanCheckStmt = $conn->prepare($scanCheckSql);
        $scanCheckStmt->bindParam(':patient_id', $patient_id);
        $scanCheckStmt->bindParam(':alert_id', $alertId);
        $scanCheckStmt->execute();

        $scanExists = $scanCheckStmt->fetchColumn() > 0;

        if ($scanExists) {
            // If the alert id exists in scans, it means it has been acknowledged
            echo json_encode(['message' => 'Alert acknowledged.']);
            exit;
        } else {
            // Return the alert if it hasn't been acknowledged
            $alert['is_acknowledged'] = 0; // Assuming it's not acknowledged
            echo json_encode($alert);
        }
    } else {
        echo json_encode(['message' => 'No alert found for the provided month.']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error fetching alert: ' . $e->getMessage()]);
}

$conn = null;
?>