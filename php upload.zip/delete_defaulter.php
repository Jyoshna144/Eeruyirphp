<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include database configuration
include 'config.php';

$data = json_decode(file_get_contents("php://input"));
$patient_id = isset($data['patient_id']) ? $data['patient_id'] : null;

// Ensure the patient_id is not empty
if (!empty($patient_id)) {
    // Prepare the SQL statement
    $sql = "DELETE FROM defaulters WHERE patient_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$patient_id]);

    // Check if a record was deleted
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Defaulter record deleted successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'No record found to delete.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid patient ID.']);
}

$conn = null;
?>