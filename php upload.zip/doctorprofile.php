<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
require 'config.php'; // Include the PDO connection

// Check the request method
$requestMethod = $_SERVER['REQUEST_METHOD'];

if ($requestMethod === 'POST') {
    // Get the JSON data from the POST request
    $postData = file_get_contents("php://input");
    $data = json_decode($postData, true);

    // Validate JSON structure
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'message' => 'Invalid JSON']);
        exit;
    }

    // Check if required fields are set for POST
    $requiredFields = ['username', 'password', 're_enter_password', 'phonenumber', 'specialization', 'experience', 'name', 'email'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            echo json_encode(['success' => false, 'message' => 'All fields are required']);
            exit;
        }
    }

    // Sanitize and hash inputs for secure storage
    $user_username = filter_var($data['username'], FILTER_SANITIZE_STRING);
    $user_password = filter_var($data['password'], FILTER_SANITIZE_STRING);
    $user_re_enter_password = filter_var($data['re_enter_password'], FILTER_SANITIZE_STRING);
    $user_phonenumber = filter_var($data['phonenumber'], FILTER_SANITIZE_STRING);
    $user_specialization = filter_var($data['specialization'], FILTER_SANITIZE_STRING);
    $user_experience = filter_var($data['experience'], FILTER_SANITIZE_NUMBER_INT);
    $user_name = filter_var($data['name'], FILTER_SANITIZE_STRING);
    $user_email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);

    // Ensure passwords match
    if ($user_password !== $user_re_enter_password) {
        echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
        exit;
    }

    // Insert data into the database
    $sql = "INSERT INTO doctorlogin (username, password, phonenumber, specialization, experience, name, email)
            VALUES (:username, :password, :phonenumber, :specialization, :experience, :name, :email)";
    $stmt = $conn->prepare($sql);
    $params = [
        ':username' => $user_username,
        ':password' => password_hash($user_password, PASSWORD_BCRYPT),
        ':phonenumber' => $user_phonenumber,
        ':specialization' => $user_specialization,
        ':experience' => $user_experience,
        ':name' => $user_name,
        ':email' => $user_email
    ];

    try {
        $stmt->execute($params);
        echo json_encode(['success' => true, 'message' => 'New record created successfully']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }

} elseif ($requestMethod === 'GET') {
    // Check if username is provided in GET request
    if (!isset($_GET['username']) || empty($_GET['username'])) {
        echo json_encode(['success' => false, 'message' => 'Username is required']);
        exit;
    }

    // Sanitize the username
    $username = filter_var($_GET['username'], FILTER_SANITIZE_STRING);

    // Fetch doctor data by username
    $sql = "SELECT username, phonenumber, specialization, experience, name, email FROM doctorlogin WHERE username = :username";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);

    try {
        $stmt->execute();
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($userData) {
            echo json_encode(['success' => true, 'data' => $userData]);
        } else {
            echo json_encode(['success' => false, 'message' => 'User not found']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Unsupported request method']);
}

// Close the database connection
$conn = null;
?>