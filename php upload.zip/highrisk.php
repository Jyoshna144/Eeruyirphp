<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration file
require 'config.php'; // Make sure the path is correct based on your folder structure

try {
    // SQL query to fetch high-risk patients along with their questions and answers
    $sql = "
        SELECT 
            pa.patient_id, 
            q.question,
            pa.answer,
            pa.answer_date
        FROM 
            patient_answers pa
        JOIN 
            questions q ON pa.question_id = q.id
        WHERE 
            pa.answer = 'yes'
        ORDER BY 
            pa.patient_id, pa.answer_date;
    ";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch all results as an associative array
    $highRiskPatients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check if any high-risk patients were found
    if ($highRiskPatients) {
        // Organize data by patient_id
        $result = [];
        foreach ($highRiskPatients as $row) {
            $result[$row['patient_id']]['high_risk_questions'][] = [
                'question' => $row['question'],
                'answer' => $row['answer'],  // Include answer
                'answer_date' => $row['answer_date'],
            ];
        }

        // Format result into desired structure
        $formattedResult = [];
        foreach ($result as $patient_id => $data) {
            $formattedResult[] = [
                'patient_id' => $patient_id,
                'high_risk_questions' => implode('; ', array_map(function ($q) {
                    return "Question: {$q['question']}, Answer: {$q['answer']}, Answer Date: {$q['answer_date']}";
                }, $data['high_risk_questions'])),
            ];
        }

        echo json_encode([
            'success' => true,
            'data' => $formattedResult,
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No high-risk patients found.',
        ]);
    }

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage(),
    ]);
}

// Close the connection
$conn = null; // Close the PDO connection
?>