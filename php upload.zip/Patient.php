<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require "config.php"; // Include the PDO connection

// Get the raw JSON input
$json_data = file_get_contents("php://input");

// Decode the JSON data into a PHP array
$request_data = json_decode($json_data, true);

// Initialize response array
$response = ['status' => 'error', 'message' => 'Invalid request data'];

// Check if the required data is set
if (isset($request_data['username']) && isset($request_data['password'])) {
    $username = $request_data['username'];
    $password = $request_data['password'];

    // Check if the request is for registration
    if (isset($request_data['register']) && $request_data['register'] === true) {
        // Prepare the SQL statement for inserting a new user
        $sql = "INSERT INTO patientsignup(username, password) VALUES (:username, :password)";
        $stmt = $conn->prepare($sql);

        // Execute the statement
        try {
            $stmt->execute([':username' => $username, ':password' => password_hash($password, PASSWORD_BCRYPT)]);
            $response = ['status' => 'success', 'message' => 'Registration successful!'];
        } catch (PDOException $e) {
            $response = ['status' => 'error', 'message' => 'Failed to register user: ' . $e->getMessage()];
        }
    } else {
        // Prepare the SQL statement for user login
        try {
            // Prepare SQL statement to retrieve user information including patientId and blocked status
            $stmt = $conn->prepare("SELECT patient_id, password, blocked FROM patientsignup WHERE username = :username");
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Check if the user is blocked
                if ($user['blocked'] == 1) {
                    $response = ['status' => 'error', 'message' => 'Your account is blocked.'];
                } else {
                    // Verify the password
                    if (password_verify($password, $user['password'])) {
                        $response = [
                            'status' => 'success',
                            'message' => 'Login successful',
                            'patient_id' => $user['patient_id'] // Include patientId in the response
                        ];
                    } else {
                        $response = ['status' => 'error', 'message' => 'Invalid password'];
                    }
                }
            } else {
                $response = ['status' => 'error', 'message' => 'User not found'];
            }
        } catch (PDOException $e) {
            $response = ['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()];
        }
    }
} else {
    $response = ['status' => 'error', 'message' => 'Invalid request method'];
}

// Return the response as JSON
echo json_encode($response);
?>