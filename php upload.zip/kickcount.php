<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include 'config.php'; // Assuming config.php is in the same directory

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $patient_id = $_POST['patient_id'];
    $action = $_POST['action']; // 'increment' or 'decrement'

    // Check if the patient ID exists in the database
    $sql = "SELECT kick_count FROM kick_counts WHERE patient_id = :patient_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR); // VARCHAR requires PDO::PARAM_STR
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        // Patient ID found, retrieve the current kick count
        $kick_count = $result['kick_count'];

        if ($action === 'increment') {
            $kick_count += 1;
        } elseif ($action === 'decrement' && $kick_count > 0) {
            $kick_count -= 1;
        }
    } else {
        // Patient ID not found, insert a new record with kick count 0
        $kick_count = 0;

        $insert_sql = "INSERT INTO kick_counts (patient_id, kick_count) VALUES (:patient_id, :kick_count)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $insert_stmt->bindParam(':kick_count', $kick_count, PDO::PARAM_INT);
        $insert_stmt->execute();

        // New patient created, so we start incrementing from 0
        $kick_count += 1; // Increment by 1 after insertion
    }

    // Update the kick count in the database
    $update_sql = "UPDATE kick_counts SET kick_count = :kick_count WHERE patient_id = :patient_id";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bindParam(':kick_count', $kick_count, PDO::PARAM_INT);
    $update_stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR); // VARCHAR requires PDO::PARAM_STR
    $update_stmt->execute();

    echo json_encode([
        "status" => "success",
        "message" => "Kick count updated successfully",
        "kick_count" => $kick_count
    ]);
} elseif ($method === 'GET') {
    $patient_id = $_GET['patient_id'];

    $sql = "SELECT kick_count FROM kick_counts WHERE patient_id = :patient_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR); // VARCHAR requires PDO::PARAM_STR
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        echo json_encode([
            "status" => "success",
            "kick_count" => $result['kick_count']
        ]);
    } else {
        // If the patient ID is not found, return a kick count of 0
        echo json_encode([
            "status" => "success", // Keep status as success since we're returning a valid response
            "kick_count" => 0 // Default kick count
        ]);
    }
}
?>