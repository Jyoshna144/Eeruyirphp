<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include your database configuration file
require "config.php";

try {
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        // Get the patient ID from the GET request
        $patientId = isset($_GET['patientId']) ? htmlspecialchars(strip_tags($_GET['patientId'])) : null;

        if ($patientId) {
            // Prepare and execute the SQL query to fetch patient details
            $sql = "SELECT q.question, q.sub_question, pr.answer, pr.questionId 
                    FROM patient_responses pr
                    JOIN questions q ON pr.questionId = q.id
                    WHERE pr.patientId = :patientId";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':patientId', $patientId, PDO::PARAM_STR);
            $stmt->execute();

            // Fetch the results
            $responses = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $responses[] = [
                    'question' => $row['question'],
                    'sub_question' => $row['sub_question'],
                    'answer' => $row['answer'],
                    'questionId' => $row['questionId']
                ];
            }

            // Return the responses in JSON format
            http_response_code(200);
            echo json_encode($responses);
        } else {
            throw new Exception("Patient ID is required.");
        }
    } elseif ($method === 'POST') {
        // Handle POST request to update patient responses
        $data = json_decode(file_get_contents("php://input"), true);
        error_log("Received data: " . json_encode($data)); // Log the received data

        $patientId = isset($data['patientId']) ? htmlspecialchars(strip_tags($data['patientId'])) : null;
        $answers = isset($data['answers']) ? $data['answers'] : [];

        if ($patientId && !empty($answers)) {
            // Prepare and execute the SQL query to update patient responses
            foreach ($answers as $questionId => $answer) {
                $sql = "UPDATE patient_responses SET answer = :answer WHERE patientId = :patientId AND questionId = :questionId";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':patientId', $patientId, PDO::PARAM_STR);
                $stmt->bindParam(':questionId', $questionId, PDO::PARAM_INT);
                $stmt->bindParam(':answer', $answer, PDO::PARAM_STR);
                $stmt->execute();
            }

            http_response_code(200);
            echo json_encode(['message' => 'Data submitted successfully.']);
        } else {
            throw new Exception("Patient ID and answers are required.");
        }
    } else {
        throw new Exception("Unsupported request method.");
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['message' => $e->getMessage()]);
} finally {
    // Close the database connection
    $conn = null;
}
?>