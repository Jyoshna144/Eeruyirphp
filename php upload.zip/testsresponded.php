<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration file
include 'config.php';

try {
    // SQL query to check if any patient_id has an alert count equal to the maximum months
    $sql = "
        SELECT 
    patient_id 
FROM 
    scans
GROUP BY 
    patient_id
HAVING 
    COUNT(alert_id) = MAX(months)
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch all results
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($result) {
        echo json_encode([$result]);
    } else {
        echo json_encode(['message' => 'Condition not met: No matching alert count for any patient.']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error executing query: ' . $e->getMessage()]);
}

$conn = null;
?>