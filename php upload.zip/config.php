<?php
// config.php

$servername = "localhost";
$username = "root";
$password = "";
$database = "eeruyir";

try {
    // Establish a new PDO connection
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);

    // Set PDO attributes for error handling and emulation
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

    // Optional: set character set to utf8
    $conn->exec("SET NAMES utf8");

    // Base URL for your project
    $base_url = 'http://192.168.69.248/eeruyir';
} catch (PDOException $e) {
    // If connection fails, handle the exception
    die("Connection failed: " . $e->getMessage());
}

// Return an array with the connection and base URL
return array('conn' => $conn, 'base_url' => $base_url);
?>