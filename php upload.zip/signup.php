<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
require_once 'config.php';

// Turn off error display and enable logging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Decode JSON input
    $data = json_decode(file_get_contents("php://input"), true);
    $username = isset($data['username']) ? htmlspecialchars($data['username']) : null;
    $password = isset($data['password']) ? htmlspecialchars($data['password']) : null;
    $phonenumber = isset($data['phonenumber']) ? htmlspecialchars($data['phonenumber']) : null;

    if ($username && $password && $phonenumber) {
        try {
            // Check if username already exists
            $stmt = $conn->prepare("SELECT COUNT(*) FROM patientsignup WHERE username = :username");
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            $userExists = $stmt->fetchColumn();

            if ($userExists) {
                echo json_encode(array('message' => 'Username already exists. Please try a different username.'));
            } else {
                // Check if the phone number matches with patients_details
                $stmt = $conn->prepare("SELECT COUNT(*) FROM patients_details WHERE phoneNumber = :phonenumber");
                $stmt->bindParam(':phonenumber', $phonenumber);
                $stmt->execute();
                $phoneMatch = $stmt->fetchColumn();

                if (!$phoneMatch) {
                    echo json_encode(array('message' => 'Sorry, phone number does not match our records.'));
                } else {
                    // Generate the next patient_id in the format PSJM000X
                    $stmt = $conn->query("SELECT MAX(patient_id) AS max_id FROM patientsignup");
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $max_id = $row['max_id'];

                    // Extract the numeric part of the patient_id (e.g., 0001, 0002, ...)
                    $last_number = (int) substr($max_id, 4); // Extract the numeric part from PSJM000X
                    $new_number = $last_number + 1;
                    $new_patient_id = 'PSJM' . str_pad($new_number, 4, '0', STR_PAD_LEFT);

                    // Hash the password
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                    // Insert the new user with the generated patient_id and phone number
                    $stmt = $conn->prepare("INSERT INTO patientsignup (username, password, patient_id, phonenumber, created_at) VALUES (:username, :password, :patient_id, :phonenumber, NOW())");
                    $stmt->bindParam(':username', $username);
                    $stmt->bindParam(':password', $hashed_password);
                    $stmt->bindParam(':patient_id', $new_patient_id);
                    $stmt->bindParam(':phonenumber', $phonenumber);

                    if ($stmt->execute()) {
                        echo json_encode(array('message' => 'User registered successfully', 'patient_id' => $new_patient_id));
                    } else {
                        echo json_encode(array('message' => 'Failed to register user'));
                    }
                }
            }
        } catch (PDOException $e) {
            echo json_encode(array('message' => 'Database error: ' . $e->getMessage()));
        }
    } else {
        echo json_encode(array('message' => 'Invalid username, password, or phone number'));
    }
} else {
    echo json_encode(array('message' => 'Invalid request method'));
}
?>