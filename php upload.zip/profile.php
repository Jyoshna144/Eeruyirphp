<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database connection file
require 'config.php';

// Get the JSON data from the request body
$data = json_decode(file_get_contents("php://input"), true);
$patient_id = isset($data['patient_id']) ? $data['patient_id'] : null;

// Check if patient ID is provided
if (!$patient_id) {
    echo json_encode(['success' => false, 'message' => 'Patient ID is required.']);
    exit;
}

try {
    // Prepare the SQL statement to fetch patient details based on patient_id
    $sql = "SELECT * FROM patients_details WHERE patient_id = :patient_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
    $stmt->execute();

    // Fetch the patient data
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);

    // Prepare a separate query to fetch all images for the given patient_id from the scans table
    $imageSql = "SELECT file_path, created_at FROM scans WHERE patient_id = :patient_id ORDER BY created_at DESC";
    $imageStmt = $conn->prepare($imageSql);
    $imageStmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
    $imageStmt->execute();

    // Fetch all images
    $images = $imageStmt->fetchAll(PDO::FETCH_ASSOC);

    // Check if patient data exists
    if ($patient) {
        // Include the patient details and images in the response
        echo json_encode([
            'success' => true,
            'patient' => $patient,
            'images' => $images
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Patient not found.']);
    }

} catch (PDOException $e) {
    // Log error and return a JSON error message
    error_log('Database error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

// Close the connection
$conn = null;
?>