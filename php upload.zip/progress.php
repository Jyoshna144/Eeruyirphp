<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration
include 'config.php';

// Check if patient_id and other necessary parameters are set in the request
if (isset($_POST['patient_id']) && isset($_POST['trimester'])) {
    $patient_id = $_POST['patient_id'];
    $trimester = $_POST['trimester'];

    try {
        // Fetch the daily video completions for the given patient and trimester
        $fetchProgressSql = "
            SELECT 
                completion_date, 
                total_videos_completed, 
                total_videos
            FROM 
                daily_video_completions
            WHERE 
                patient_id = :patient_id 
                AND trimester = :trimester
            ORDER BY 
                completion_date ASC
        ";

        $fetchProgressStmt = $conn->prepare($fetchProgressSql);
        $fetchProgressStmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $fetchProgressStmt->bindParam(':trimester', $trimester, PDO::PARAM_STR);
        $fetchProgressStmt->execute();
        $progressData = $fetchProgressStmt->fetchAll(PDO::FETCH_ASSOC);

        // Check if data is retrieved
        if (empty($progressData)) {
            echo json_encode(['error' => 'No data found for the given patient and trimester']);
        } else {
            echo json_encode($progressData);
        }

    } catch (PDOException $e) {
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Missing parameters']);
}
?>