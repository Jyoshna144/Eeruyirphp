<?php
// Include the config.php to establish the database connection
include 'config.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

try {
    // SQL query to get delivery outcomes, patient details, and exercise records
    $sql = "SELECT 
    d.patient_id,
    d.delivery_method,
    d.difficulty,
    p.firstName,
    p.lastName
FROM (
    SELECT patient_id,
           MIN(lmp_date) AS lmp_date,
           COUNT(DISTINCT CASE 
                           WHEN exercise_days >= 20 THEN CONCAT(exercise_year, '-', exercise_month) 
                         END) AS valid_months,
           COUNT(DISTINCT CONCAT(exercise_year, '-', exercise_month)) AS total_months,
           DAY(MIN(lmp_date)) AS lmp_day
    FROM patient_monthly_exercise
    GROUP BY patient_id
) AS subquery
JOIN delivery_outcomes d ON subquery.patient_id = d.patient_id
JOIN patients_details p ON subquery.patient_id = p.patient_id  -- Ensure this is the correct patient table
WHERE valid_months = total_months 
      - (CASE  
          WHEN lmp_day > 10 THEN 1 
          ELSE 0 
      END) 
      - (CASE  
          WHEN DAY(CURRENT_DATE()) < 20 THEN 1 
          ELSE 0 
      END);
";

    // Prepare and execute the query
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch all rows as an associative array
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Initialize arrays for categorized patients
    $normalPatients = [];
    $lsPatients = [];
    $exercisePatients = [];
    $exerciseNormalPatients = [];
    $exerciseLsPatients = [];

    // Categorize patients based on delivery method and exercise days
    foreach ($patients as $row) {
        $exercisePatients[] = $row; // All patients who exercised at least 20 days
        if ($row['delivery_method'] === 'Normal') {
            $normalPatients[] = $row;
            $exerciseNormalPatients[] = $row; // Normal patients who exercised at least 20 days
        } elseif ($row['delivery_method'] === 'C-Section') {
            $lsPatients[] = $row;
            $exerciseLsPatients[] = $row; // LSCS patients who exercised at least 20 days
        }
    }

    // Prepare the response data
    $response = [
        'patients' => $exercisePatients,
        'normalPatients' => [
            'count' => count($normalPatients),
            'patients' => array_map(function ($patient) {
                $patient['profile_url'] = "view_profile.php?patient_id=" . $patient['patient_id'];
                return $patient;
            }, $normalPatients)
        ],
        'lsPatients' => [
            'count' => count($lsPatients),
            'patients' => array_map(function ($patient) {
                $patient['profile_url'] = "view_profile.php?patient_id=" . $patient['patient_id'];
                return $patient;
            }, $lsPatients)
        ],
        'exercisePatients' => $exercisePatients,
        'exerciseNormalPatients' => [
            'count' => count($exerciseNormalPatients),
            'patients' => array_map(function ($patient) {
                $patient['profile_url'] = "view_profile.php?patient_id=" . $patient['patient_id'];
                return $patient;
            }, $exerciseNormalPatients)
        ],
        'exerciseLsPatients' => [
            'count' => count($exerciseLsPatients),
            'patients' => array_map(function ($patient) {
                $patient['profile_url'] = "view_profile.php?patient_id=" . $patient['patient_id'];
                return $patient;
            }, $exerciseLsPatients)
        ]
    ];

    // Send the response as JSON
    echo json_encode($response);
} catch (PDOException $e) {
    // Handle any exceptions or errors
    echo json_encode(['error' => $e->getMessage()]);
}
?>