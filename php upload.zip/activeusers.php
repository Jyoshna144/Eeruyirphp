<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the config.php to establish the database connection
include 'config.php';


try {
    // SQL query to count patients who have exercised more than 20 days in every month from their lmpDate to the current date
    $sql = "SELECT COUNT(*) AS followUpCount
        FROM (
            SELECT patient_id,
                   MIN(lmp_date) AS lmp_date,
                   COUNT(DISTINCT CASE 
                                   WHEN exercise_days >= 20 THEN CONCAT(exercise_year, '-', exercise_month) 
                                 END) AS valid_months,
                   COUNT(DISTINCT CONCAT(exercise_year, '-', exercise_month)) AS total_months,
                   DAY(MIN(lmp_date)) AS lmp_day,
                   MONTH(MIN(lmp_date)) AS lmp_month,
                   YEAR(MIN(lmp_date)) AS lmp_year
            FROM patient_monthly_exercise
            GROUP BY patient_id
        ) AS subquery
        WHERE valid_months = total_months 
              -  (CASE  
                  WHEN lmp_day > 10 THEN 1 
                  ELSE 0 
              END)-(CASE  
                  WHEN DAY(CURRENT_DATE())<20 THEN 1 
                  ELSE 0 
              END)";


    // Prepare and execute the query
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch the count
    $followUpCount = $stmt->rowCount();

    // Prepare the response data
    $response = [
        'followUpCount' => $followUpCount
    ];

    // Send the response as JSON
    echo json_encode($response);
} catch (PDOException $e) {
    // Handle any exceptions or errors
    echo json_encode(['error' => $e->getMessage()]);
}
?>