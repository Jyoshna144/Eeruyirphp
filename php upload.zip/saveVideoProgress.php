<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration
include 'config.php';

// Check if patient_id and other necessary parameters are set in the request
if (isset($_POST['patientId']) && isset($_POST['videoId']) && isset($_POST['completionDate']) && isset($_POST['trimester'])) {
    $patient_id = $_POST['patientId'];
    $video_id = $_POST['videoId'];
    $completion_date = $_POST['completionDate'];
    $trimester = $_POST['trimester'];
    $total_videos = countVideosForTrimester($trimester);

    try {
        // Check if an entry already exists for the given patient and date
        $insertVideoSql = 'INSERT INTO video_completions (patient_id, trimester, video_id, completion_date) VALUES (:patient_id, :trimester, :video_id, :completion_date)';
        $insertVideoStmt = $conn->prepare($insertVideoSql);
        $insertVideoStmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $insertVideoStmt->bindParam(':trimester', $trimester, PDO::PARAM_STR); // Changed to PDO::PARAM_STR
        $insertVideoStmt->bindParam(':video_id', $video_id, PDO::PARAM_STR);
        $insertVideoStmt->bindParam(':completion_date', $completion_date, PDO::PARAM_STR);
        $insertVideoStmt->execute();

        echo json_encode(['success' => 'Video completion data saved successfully.']);

        // Update daily_video_completions table
        $sql = "
            INSERT INTO daily_video_completions (patient_id, completion_date, trimester, total_videos_completed, total_videos)
            SELECT 
                vc.patient_id, 
                vc.completion_date, 
                vc.trimester AS trimester,
                COUNT(vc.video_id) AS total_videos_completed,
                (SELECT COUNT(*) FROM videos v WHERE v.trimester_id = vc.trimester) AS total_videos
            FROM 
                video_completions vc
            WHERE 
                vc.patient_id = :patient_id AND 
                vc.completion_date = :completion_date AND 
                vc.trimester = :trimester
            GROUP BY 
                vc.patient_id, 
                vc.completion_date, 
                vc.trimester
            ON DUPLICATE KEY UPDATE 
                total_videos_completed = VALUES(total_videos_completed),
                total_videos = VALUES(total_videos);
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $stmt->bindParam(':completion_date', $completion_date, PDO::PARAM_STR);
        $stmt->bindParam(':trimester', $trimester, PDO::PARAM_STR);
        $stmt->execute();

        echo json_encode(['success' => 'Daily video completion data updated successfully.']);

        // Update monthly_exercise_days for the current month
        $updateMonthlySql = "
            UPDATE daily_video_completions dvc
            JOIN (
                SELECT patient_id,
                       COUNT(DISTINCT DATE(completion_date)) AS exercise_days_in_month
                FROM daily_video_completions
                WHERE YEAR(completion_date) = YEAR(CURDATE()) -- Current year
                  AND MONTH(completion_date) = MONTH(CURDATE()) -- Current month
                GROUP BY patient_id
            ) AS subquery
            ON dvc.patient_id = subquery.patient_id
            SET dvc.monthly_exercise_days = subquery.exercise_days_in_month
            WHERE YEAR(dvc.completion_date) = YEAR(CURDATE())
              AND MONTH(dvc.completion_date) = MONTH(CURDATE());
        ";

        $updateMonthlyStmt = $conn->prepare($updateMonthlySql);
        $updateMonthlyStmt->execute();

        echo json_encode(['success' => 'Monthly exercise days updated successfully.']);



        // Update patient_monthly_exercise table
        $updatePatientMonthlySql = "
            INSERT INTO patient_monthly_exercise(patient_id, lmp_date, exercise_year, exercise_month, exercise_days)
            SELECT
                pd.patient_id,
                pd.lmpDate,
                YEAR(dvc.completion_date) AS exercise_year,
                MONTH(dvc.completion_date) AS exercise_month,
                COUNT(DISTINCT DATE(dvc.completion_date)) AS exercise_days
            FROM
                daily_video_completions dvc
            JOIN
                patients_details pd ON dvc.patient_id = pd.patient_id
            WHERE
                dvc.completion_date >= pd.lmpDate
                AND YEAR(dvc.completion_date) = YEAR(CURDATE())
                AND MONTH(dvc.completion_date) = MONTH(CURDATE())
            GROUP BY
                pd.patient_id, pd.lmpDate, exercise_year, exercise_month
            ON DUPLICATE KEY UPDATE
                exercise_days = VALUES(exercise_days);
        ";

        $updatePatientMonthlyStmt = $conn->prepare($updatePatientMonthlySql);
        $updatePatientMonthlyStmt->execute();

        echo json_encode(['success' => 'Patient monthly exercise data updated successfully.']);

    } catch (PDOException $e) {
        // Handle SQL errors, particularly unique constraint violations
        if ($e->getCode() == 23000) { // 23000 is the SQLSTATE code for integrity constraint violation
            echo json_encode(['error' => 'This video has already been completed today.']);
        } else {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
    }
} else {
    // Handle missing parameters
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Missing parameters']);
}

function countVideosForTrimester($trimester)
{
    // This function should return the total number of videos for the given trimester.
    // You can either hardcode the values or retrieve them from the database if they are dynamic.
    $videos = [
        '1' => 10, // Total videos for 1st Trimester
        '2' => 14, // Total videos for 2nd Trimester
        '3' => 1, // Total videos for 3rd Trimester (updated to a more realistic number)
    ];

    return isset($videos[$trimester]) ? $videos[$trimester] : 0;
}
?>