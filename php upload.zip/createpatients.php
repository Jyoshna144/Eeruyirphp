<?php
// Ensure headers allow cross-origin requests and set content type
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
require "config.php";

// Function to generate a new patient ID
function generatePatientID($conn)
{
    // Query to get the latest patient ID from the database
    $sql = "SELECT MAX(patient_id) AS max_id FROM patients_details";
    $result = $conn->query($sql);
    $row = $result->fetch(PDO::FETCH_ASSOC);

    // Extract the maximum patient ID and increment
    if ($row['max_id']) {
        $max_id = intval(substr($row['max_id'], 2)); // Extract numeric part and convert to integer
        $new_id = "P_" . str_pad($max_id + 1, 2, "0", STR_PAD_LEFT); // Increment and format
    } else {
        // If no existing IDs, start with P_01
        $new_id = "P_01";
    }

    return $new_id;
}

try {
    // Get the input data from the request
    $data = json_decode(file_get_contents("php://input"), true);

    if (!empty($data)) {
        $firstName = htmlspecialchars(strip_tags($data['firstName']));
        $lastName = htmlspecialchars(strip_tags($data['lastName']));
        $age = intval($data['age']);
        $education = htmlspecialchars(strip_tags($data['education']));
        $occupation = htmlspecialchars(strip_tags($data['occupation']));
        $phoneNumber = htmlspecialchars(strip_tags($data['phoneNumber']));
        $bloodGroup = htmlspecialchars(strip_tags($data['bloodGroup']));
        $lmpDate = date('Y-m-d', strtotime(htmlspecialchars(strip_tags($data['lmpDate']))));
        $dueDate = date('Y-m-d', strtotime(htmlspecialchars(strip_tags($data['dueDate']))));
        $abortionHistory = htmlspecialchars(strip_tags($data['abortionHistory']));
        $relativeToHusband = htmlspecialchars(strip_tags($data['relativeToHusband']));
        $confirmationOfPregnancy = htmlspecialchars(strip_tags($data['confirmationOfPregnancy']));
        $weight = floatval($data['weight']);
        $Height = floatval($data['Height']);
        $obstetricScore = isset($data['obstetricScore']) ? intval($data['obstetricScore']) : 0;
        $maritalStatus = htmlspecialchars(strip_tags($data['maritalStatus']));
        $today = date("Y-m-d");



        // Check if phone number already exists
        $checkPhoneStmt = $conn->prepare("SELECT patient_id FROM patients_details WHERE phoneNumber = :phoneNumber");
        $checkPhoneStmt->bindParam(':phoneNumber', $phoneNumber);
        $checkPhoneStmt->execute();

        if ($checkPhoneStmt->rowCount() > 0) {
            // Phone number already exists, return error message
            echo json_encode(['message' => 'Mobile number already present']);
        } else {
            // Generate patient ID
            $patient_id = generatePatientID($conn);

            // Prepare the SQL insert statement
            $stmt = $conn->prepare("INSERT INTO patients_details 
                (patient_id, firstName, lastName, age, education, occupation, phoneNumber, bloodGroup, 
                lmpDate, dueDate, abortionHistory, relativeToHusband, confirmationOfPregnancy, 
                weight, Height, obstetricScore, maritalStatus) 
                VALUES 
                (:patient_id, :firstName, :lastName, :age, :education, :occupation, :phoneNumber, :bloodGroup, 
                :lmpDate, :dueDate, :abortionHistory, :relativeToHusband, :confirmationOfPregnancy, 
                :weight, :Height, :obstetricScore, :maritalStatus)");

            // Bind parameters
            $stmt->bindParam(':patient_id', $patient_id);
            $stmt->bindParam(':firstName', $firstName);
            $stmt->bindParam(':lastName', $lastName);
            $stmt->bindParam(':age', $age, PDO::PARAM_INT);
            $stmt->bindParam(':education', $education);
            $stmt->bindParam(':occupation', $occupation);
            $stmt->bindParam(':phoneNumber', $phoneNumber);
            $stmt->bindParam(':bloodGroup', $bloodGroup);
            $stmt->bindParam(':lmpDate', $lmpDate);
            $stmt->bindParam(':dueDate', $dueDate);
            $stmt->bindParam(':abortionHistory', $abortionHistory);
            $stmt->bindParam(':relativeToHusband', $relativeToHusband);
            $stmt->bindParam(':confirmationOfPregnancy', $confirmationOfPregnancy);
            $stmt->bindParam(':weight', $weight);
            $stmt->bindParam(':Height', $Height);
            $stmt->bindParam(':obstetricScore', $obstetricScore, PDO::PARAM_INT);
            $stmt->bindParam(':maritalStatus', $maritalStatus);

            // Execute the insert statement
            if ($stmt->execute()) {
                echo json_encode(['message' => 'Patient details saved successfully.', 'patient_id' => $patient_id]);
            } else {
                echo json_encode(['message' => 'Error saving patient details']);
            }

            $stmt->closeCursor();
        }
    } else {
        echo json_encode(['message' => 'No data provided']);
    }

    $conn = null; // Close database connection
} catch (Exception $e) {
    echo json_encode(['message' => 'Error: ' . $e->getMessage()]);
}
?>