<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include 'config.php'; // Include your database connection

// Directory where the uploaded files will be saved
$targetDir = "uploads/"; // Ensure this directory exists and has appropriate permissions

// Check if POST data exists
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Extract and sanitize POST data
    $patient_id = isset($_POST['patient_id']) ? htmlspecialchars($_POST['patient_id']) : null;
    $alert_id = isset($_POST['alert_id']) ? htmlspecialchars($_POST['alert_id']) : null;
    $months = isset($_POST['months']) ? htmlspecialchars($_POST['months']) : null;



    // Validate data (you may want to add more validation here)
    if ($patient_id && $alert_id) {
        // Process the uploaded file
        if (isset($_FILES["scanImage"]) && $_FILES["scanImage"]["error"] === UPLOAD_ERR_OK) {
            // Prepare the file path
            $targetFile = $targetDir . basename($_FILES["scanImage"]["name"]);

            // Validate the file type (optional)
            $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

            if (in_array($fileType, $allowedTypes)) {
                // Move the uploaded file to the target directory
                if (move_uploaded_file($_FILES["scanImage"]["tmp_name"], $targetFile)) {
                    // Prepare SQL statement to insert data into the scans table
                    $stmt = $conn->prepare("INSERT INTO scans (patient_id, months,alert_id, file_path, created_at) VALUES (:patient_id, :months,:alert_id, :file_path, NOW())");
                    $stmt->bindParam(':patient_id', $patient_id);
                    $stmt->bindParam(':alert_id', $alert_id);
                    $stmt->bindParam(':file_path', $targetFile);
                    $stmt->bindParam(':months', $months);

                    if ($stmt->execute()) {
                        // Respond with a success message
                        echo json_encode(array('message' => 'File uploaded successfully and data saved.'));
                    } else {
                        // Respond with an error message
                        echo json_encode(array('message' => 'Failed to save data in the database.'));
                    }
                } else {
                    // Respond with an error message
                    echo json_encode(array('message' => 'Failed to move uploaded file.'));
                }
            } else {
                echo json_encode(array('message' => 'Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.'));
            }
        } else {
            echo json_encode(array('message' => 'No file was uploaded or there was an upload error.'));
        }
    } else {
        // Invalid data received
        echo json_encode(array('message' => 'Invalid patient ID or alert ID.'));
    }
} else {
    // Invalid request method
    echo json_encode(array('message' => 'Invalid request method.'));
}
?>