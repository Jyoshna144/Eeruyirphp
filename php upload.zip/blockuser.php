<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include 'config.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $patient_id = $data['patient_id']; // patient_id is treated as a string
    $blocked = $data['blocked']; // this should still be an integer (0 or 1)

    // Prepare the SQL statement to update the blocked status
    $query = "UPDATE patientsignup SET blocked = :blocked WHERE patient_id = :patient_id";
    $stmt = $conn->prepare($query);

    // Bind the parameters to prevent SQL injection
    $stmt->bindParam(':blocked', $blocked, PDO::PARAM_INT);
    $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR); // Change to PARAM_STR for VARCHAR

    // Execute the query and handle the response
    try {
        if ($stmt->execute()) {
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false, "error" => "Failed to update blocked status."]);
        }
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "error" => $e->getMessage()]);
    }

    $stmt = null; // Close the statement
}
$conn = null; // Close the connection
?>