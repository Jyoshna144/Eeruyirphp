<?php
// Include the database connection file
$config = require_once('config.php');
$conn = $config['conn'];

// Set the headers to force the browser to download the file
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="data_export.csv"');

// Open the output stream
$output = fopen('php://output', 'w');

try {
    // Use a SQL query to fetch all rows from the 'addpatients' table
    $query = "SELECT * FROM addpatient";
    $stmt = $conn->prepare($query);
    $stmt->execute();

    // Fetch the field names (column headers) from the first row
    $columns = array_keys($stmt->fetch(PDO::FETCH_ASSOC));

    // Write the column headers to the CSV file
    fputcsv($output, $columns);

    // Reset the PDO statement cursor and fetch rows to write data
    $stmt->execute(); // Re-execute the query to reset fetch state

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, $row); // Write each row
    }
} catch (PDOException $e) {
    // Handle any errors
    fwrite($output, "Error: " . $e->getMessage());
} finally {
    // Close the output stream
    fclose($output);
}
?>
