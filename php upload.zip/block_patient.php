<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the configuration file
require 'config.php';

try {
    // Create a new PDO instance
    if (!isset($_GET['patient_id'])) {
        echo json_encode(['error' => 'patient_id is required']);
        exit;
    }

    $patient_id = $_GET['patient_id'];

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("UPDATE patientsignup SET blocked = 1 WHERE patient_id = :patient_id");
    $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to execute query.']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

// Close the connection
$conn = null;
?>