<?php
require 'config.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['patientId'])) {
        // Trim any whitespace or newline characters
        $patientId = trim($_GET['patientId']);

        // Log the received patientId for debugging
        error_log("Received patientId: " . $patientId);

        try {
            $sql = "SELECT lmpDate FROM patients_details WHERE patient_id = :patient_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':patient_id', $patientId, PDO::PARAM_STR);
            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                echo json_encode([
                    'status' => 'success',
                    'lmpDate' => $result['lmpDate']
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'No record found for the provided patient_id',
                    'patientId' => $patientId // Adding patientId to debug the issue
                ]);
            }
        } catch (PDOException $e) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Database query error: ' . $e->getMessage(),
                'sql' => $sql, // Adding the SQL query to debug
                'patientId' => $patientId // Adding patientId to debug the issue
            ]);
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'patientId parameter is required'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
}
?>