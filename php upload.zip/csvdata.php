<?php
// Include the database connection file
include 'config.php';

// Set the headers to force the browser to download the file
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="data_export.csv"');

// Open the output stream
$output = fopen('php://output', 'w');

// Use PDO to fetch all rows from the 'patients' table
try {
    // Prepare the query
    $stmt = $conn->prepare("SELECT * FROM patients_details");
    
    // Execute the query
    $stmt->execute();

    // Get the column names for headers
    $columns = array_keys($stmt->fetch(PDO::FETCH_ASSOC)); // Fetch one row to get column names
    fputcsv($output, $columns); // Write column names as the CSV header

    // Fetch all the rows and write them to the CSV file
    $stmt->execute(); // Execute again to reset the pointer
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, $row); // Write each row to the CSV
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Close the output stream
fclose($output);

// Close the database connection
$conn = null;
?>
