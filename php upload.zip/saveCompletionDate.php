<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration file
require 'config.php';

// Get POST data
error_log(print_r($_POST, true)); // Log POST data for debugging

$patientId = $_POST['patientId'] ?? null;
$videoId = $_POST['videoId'] ?? null;
$trimester = $_POST['trimester'] ?? null;
$completionDate = $_POST['completionDate'] ?? null;

// Validate input and gather missing fields
$missingFields = [];

if (!$patientId) {
    $missingFields[] = 'patientId';
}
if (!$videoId) {
    $missingFields[] = 'videoId';
}
if (!$trimester) {
    $missingFields[] = 'trimester';
}
if (!$completionDate) {
    $missingFields[] = 'completionDate';
}

if (!empty($missingFields)) {
    echo "Missing required fields: " . implode(', ', $missingFields);
    exit;
}

try {
    // Prepare and execute the SQL query
    $stmt = $conn->prepare("INSERT INTO video_completions(patient_id, trimester, video_id, completion_date) VALUES (:patient_id, :trimester, :video_id, :completion_date)");
    $stmt->execute([
        ':patient_id' => $patientId,
        ':trimester' => $trimester,
        ':video_id' => $videoId,
        ':completion_date' => $completionDate,
    ]);

    echo "Video completion saved successfully.";
} catch (PDOException $e) {
    // Return a more detailed error message
    echo "Failed to save video completion: " . $e->getMessage();
}
?>