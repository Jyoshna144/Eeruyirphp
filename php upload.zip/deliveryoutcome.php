<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the configuration file to establish database connection
require 'config.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the input data
    $patient_id = isset($_POST['patient_id']) ? $_POST['patient_id'] : 'Not Provided';
    $delivery_method = isset($_POST['delivery_method']) ? $_POST['delivery_method'] : 'Not Provided';
    $difficulty = isset($_POST['difficulty']) ? $_POST['difficulty'] : null;

    // Log input data for debugging
    error_log("Received POST data - patient_id: $patient_id, delivery_method: $delivery_method, difficulty: $difficulty");

    try {
        // Check if the patient ID already exists in the delivery_outcomes table
        $checkStmt = $conn->prepare("SELECT COUNT(*) FROM delivery_outcomes WHERE patient_id = :patient_id");
        $checkStmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $checkStmt->execute();
        $count = $checkStmt->fetchColumn();

        if ($count > 0) {
            // Patient ID already exists, return an appropriate message
            echo json_encode(['status' => 'error', 'message' => 'You have already entered data. You are not eligible to enter again.']);
            exit;  // Exit the script after returning the message
        }

        // Prepare an SQL statement to insert the delivery data
        $stmt = $conn->prepare("INSERT INTO delivery_outcomes (patient_id, delivery_method, difficulty, created_at) VALUES (:patient_id, :delivery_method, :difficulty, NOW())");

        // Bind the parameters to the SQL query
        $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR); // Change to PDO::PARAM_STR since patient_id is varchar
        $stmt->bindParam(':delivery_method', $delivery_method, PDO::PARAM_STR);
        $stmt->bindParam(':difficulty', $difficulty, PDO::PARAM_STR);

        // Execute the SQL statement
        $stmt->execute();

        // Return a success response
        echo json_encode(['status' => 'success', 'message' => 'Delivery data saved successfully!']);
    } catch (PDOException $e) {
        // Return an error response if the query fails
        echo json_encode(['status' => 'error', 'message' => 'Failed to save delivery data: ' . $e->getMessage()]);
    }
} else {
    // Return an error response if the request method is not POST
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>