<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include 'config.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Base URL for resources
    $baseUrl = "http://180.235.121.245/eeruyir/";

    // Read the raw POST data (for JSON request)
    $data = json_decode(file_get_contents("php://input"), true);

    // Extract the trimester value from POST data
    $trimester = isset($data['trimester']) ? htmlspecialchars($data['trimester']) : null;

    // Log the received POST data and trimester for debugging
    file_put_contents('php://stderr', "POST Data: " . print_r($data, true) . "\n");
    file_put_contents('php://stderr', "Trimester received: " . $trimester . "\n");

    // Check if the trimester is missing or invalid
    if (!$trimester) {
        echo json_encode(array(
            'status' => 'error',
            'message' => 'Trimester is missing or invalid.'
        ));
        exit;
    }

    // Validate trimester value
    $validTrimesters = ['1st Trimester', '2nd Trimester', '3rd Trimester'];
    if (!in_array($trimester, $validTrimesters)) {
        echo json_encode(array(
            'status' => 'error',
            'message' => 'Invalid trimester provided.'
        ));
        exit;
    }

    try {
        // Prepare SQL query to fetch videos for the given trimester
        $query = "SELECT id,video_name, video_path, thumbnail FROM videos WHERE trimester = :trimester";
        file_put_contents('php://stderr', "Query: " . $query . " with trimester: " . $trimester . "\n");

        $stmt = $conn->prepare($query);
        $stmt->bindParam(':trimester', $trimester);

        if ($stmt->execute()) {
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($result)) {
                // Append base URL to video_path and thumbnail
                foreach ($result as &$row) {
                    $row['id'] = $row['id'];
                    $row['video_path'] = $baseUrl . $row['video_path'];
                    $row['thumbnail'] = $baseUrl . $row['thumbnail'];
                }

                echo json_encode(array(
                    'status' => 'success',
                    'data' => $result
                ));
            } else {
                echo json_encode(array(
                    'status' => 'error',
                    'message' => 'No videos found for the specified trimester.'
                ));
            }
        } else {
            echo json_encode(array(
                'status' => 'error',
                'message' => 'Failed to execute query.'
            ));
        }
    } catch (PDOException $e) {
        echo json_encode(array(
            'status' => 'error',
            'message' => 'Database error: ' . $e->getMessage()
        ));
    }
} else {
    echo json_encode(array(
        'status' => 'error',
        'message' => 'Invalid request method.'
    ));
}
