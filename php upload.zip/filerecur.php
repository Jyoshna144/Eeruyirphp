<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database configuration file
include 'config.php';

// Get the patient_id from the request
if (!isset($_GET['patient_id'])) {
    echo json_encode(['error' => 'patient_id is required']);
    exit;
}

$patient_id = $_GET['patient_id'];

// Question IDs for various repeat schedules
$question_ids_8_months = [1, 2, 4, 7, 9, 10, 13, 14, 15, 16, 17]; // Questions repeated for 8 months
$question_id_6_months = 12; // Question repeated for 6 months
$question_ids_special = [6, 5, 8, 19]; // Special questions repeated monthly until 8 months, then bi-weekly

// Set default values for months to repeat
$months_8 = 8;
$months_6 = 6;

// Get patient data, including LMP and Due Dates, for calculation
$sql_patient = "SELECT `lmpDate`, `dueDate` FROM `patients_details` WHERE `patient_id` = :patient_id";
$stmt_patient = $conn->prepare($sql_patient);
$stmt_patient->bindParam(':patient_id', $patient_id, PDO::PARAM_INT);
$stmt_patient->execute();
$patient = $stmt_patient->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    echo json_encode(['error' => 'Patient not found.']);
    exit;
}

// Convert LMP Date and Due Date to DateTime objects
$lmpDate = new DateTime($patient['lmpDate']);
$dueDate = new DateTime($patient['dueDate']);
$eightMonthMark = clone $lmpDate;
$eightMonthMark->modify('+8 months');

// Get today's date
$today = new DateTime();
$todayFormatted = $today->format('Y-m-d');

// Check if the patient has already answered questions today
$sql_check_answers = "SELECT `answer_id` 
                      FROM `patient_answers` 
                      WHERE `patient_id` = :patient_id 
                      AND `answer_date` = :today";
$stmt_check_answers = $conn->prepare($sql_check_answers);
$stmt_check_answers->bindParam(':patient_id', $patient_id, PDO::PARAM_INT);
$stmt_check_answers->bindParam(':today', $todayFormatted, PDO::PARAM_STR);
$stmt_check_answers->execute();
$answered_today = $stmt_check_answers->fetch(PDO::FETCH_ASSOC);

// If the patient has answered questions today, return an empty array
if ($answered_today) {
    echo json_encode([1]);
    exit;
}

// Create an empty array to hold today's questions
$questions_today = [];

// Repeat questions for 8 months
for ($month = 1; $month <= $months_8; $month++) {
    $date = clone $lmpDate;
    $date->modify("+$month months");

    if ($date->format('Y-m-d') === $todayFormatted) {
        // Query to get questions for the given question IDs for 8 months
        $sql = "SELECT `id`, `question`, `sub_question` 
                FROM `questions` 
                WHERE `id` IN (" . implode(',', $question_ids_8_months) . ")";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            foreach ($result as $row) {
                $row['exact_date'] = $date->format('F j, Y');
                $questions_today[] = $row;
            }
        }
    }
}

// Repeat Question 12 for 6 months
for ($month = 1; $month <= $months_6; $month++) {
    $date = clone $lmpDate;
    $date->modify("+$month months");

    if ($date->format('Y-m-d') === $todayFormatted) {
        $sql = "SELECT `id`, `question`, `sub_question` 
                FROM `questions` 
                WHERE `id` = :question_id_6_months";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':question_id_6_months', $question_id_6_months, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $result['exact_date'] = $date->format('F j, Y');
            $questions_today[] = $result;
        }
    }
}

// Repeat Special Questions (6, 5, 8, 19) Monthly for 8 Months, Bi-Weekly After
$currentDate = clone $lmpDate;
while ($currentDate <= $dueDate) {
    if ($currentDate->format('Y-m-d') === $todayFormatted) {
        // Check if we are within the first 8 months (monthly)
        if ($currentDate <= $eightMonthMark) {
            // Query to get the special questions (monthly for the first 8 months)
            $sql = "SELECT `id`, `question`, `sub_question` 
                    FROM `questions` 
                    WHERE `id` IN (" . implode(',', $question_ids_special) . ")";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($result) {
                foreach ($result as $row) {
                    $row['exact_date'] = $currentDate->format('F j, Y');
                    $questions_today[] = $row;
                }
            }
        } else {
            // After 8 months, switch to bi-weekly
            $sql = "SELECT `id`, `question`, `sub_question` 
                    FROM `questions` 
                    WHERE `id` IN (" . implode(',', $question_ids_special) . ")";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($result) {
                foreach ($result as $row) {
                    $row['exact_date'] = $currentDate->format('F j, Y');
                    $questions_today[] = $row;
                }
            }
        }
    }

    // Move to next date based on whether we are in the first 8 months or bi-weekly after 8 months
    $currentDate->modify($currentDate <= $eightMonthMark ? '+1 month' : '+2 weeks');
}

// Logic to check if questions have been attended (optional logic based on your conditions)
$questions_attended = true; // This should be determined by your logic

if (!$questions_attended) {
    // Update the blocked status to 1 (blocked)
    $update_stmt = $conn->prepare("INSERT INTO defaulters (patient_id) VALUES (:patient_id)");
    $update_stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_INT);
    $update_stmt->execute();
}

// Close the PDO connection (optional)
$conn = null;

// Return today's questions as JSON
header('Content-Type: application/json');
echo json_encode($questions_today);
?>