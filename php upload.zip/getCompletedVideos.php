<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration
include 'config.php';

// Check if patient_id is set in the query string
if (isset($_GET['patient_id'])) {
    $patient_id = $_GET['patient_id'];

    try {
        // Prepare the SQL query to select video_id for videos completed today
        $sql = 'SELECT video_id FROM video_completions WHERE patient_id = :patient_id AND DATE(completion_date) = CURDATE()';
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $stmt->execute();

        // Fetch all results as an array of video_ids
        $completedVideos = $stmt->fetchAll(PDO::FETCH_COLUMN, 0); // Fetch only the first column (video_id)

        // Set response header to JSON
        header('Content-Type: application/json');

        // Output the results in JSON format
        echo json_encode($completedVideos);
    } catch (PDOException $e) {
        // Handle SQL errors
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    // Handle missing patient_id
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Missing patient_id']);
}
?>