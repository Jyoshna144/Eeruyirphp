<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Include the database configuration file
include 'config.php';

// SQL query to select patient_id from defaulters_list
$sql_check_defaulters = "
    SELECT patient_id FROM defaulters
";

// Prepare and execute the query
$stmt_check_defaulters = $conn->prepare($sql_check_defaulters);
$stmt_check_defaulters->execute();

// Fetch all the results
$defaulters = $stmt_check_defaulters->fetchAll(PDO::FETCH_ASSOC);

// Return the results as a JSON response
if ($defaulters) {
    // Output the list of defaulters as JSON
    echo json_encode($defaulters);
} else {
    // If no defaulters are found, return an empty JSON array
    echo json_encode([]);
}

// Close the PDO connection (optional)
$conn = null;
?>