<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database configuration
include 'config.php';

try {
    // Prepare the SQL query
    $sql = "SELECT patient_id, created_at FROM patientsignup ORDER BY created_at DESC LIMIT 10";

    // Execute the query
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch all results
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return results as JSON
    echo json_encode($patients);

} catch (PDOException $e) {
    // Handle potential errors
    echo json_encode(array('error' => $e->getMessage()));
}
?>