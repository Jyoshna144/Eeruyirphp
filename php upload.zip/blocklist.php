<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database configuration
include 'config.php';

try {
    // Prepare the SQL query to fetch blocked patient IDs
    $sql = "SELECT patient_id FROM patientsignup WHERE blocked = :blocked";
    $stmt = $conn->prepare($sql);

    // Bind the 'blocked' parameter value
    $blocked = 1; // Blocked status value
    $stmt->bindParam(':blocked', $blocked, PDO::PARAM_INT);

    // Execute the query
    $stmt->execute();

    // Fetch all blocked patient IDs
    $blockedPatients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check if any blocked patients exist and return the response as JSON
    if (!empty($blockedPatients)) {
        echo json_encode($blockedPatients);
    } else {
        echo json_encode(['message' => 'No blocked patients found.']);
    }

} catch (PDOException $e) {
    // Handle potential errors and return in JSON format
    echo json_encode(['error' => $e->getMessage()]);
}
?>