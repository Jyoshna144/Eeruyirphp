<?php
// Include the database connection configuration file
include 'config.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Retrieve patient_id from the request
$input = file_get_contents('php://input');
$data = json_decode($input, true);
$patient_id = isset($data['patient_id']) ? $data['patient_id'] : null;

$response = [];

// Check if patient_id is provided
if ($patient_id) {
    try {
        // Prepare the SQL statement to insert a new defaulter record
        $stmt = $conn->prepare("INSERT INTO defaulters (patient_id) VALUES (:patient_id)");
        $stmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR); // Bind as a string

        // Execute the statement
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Patient marked as defaulter successfully.';
        } else {
            $response['success'] = false;
            $response['message'] = 'Failed to mark patient as defaulter.';
        }
    } catch (PDOException $e) {
        // Handle database connection errors
        $response['success'] = false;
        $response['message'] = 'Database error: ' . $e->getMessage();
    }
} else {
    $response['success'] = false;
    $response['message'] = 'Patient ID is required.';
}

// Return the JSON response
echo json_encode($response);
?>